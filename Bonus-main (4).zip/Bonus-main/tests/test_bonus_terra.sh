#!/usr/bin/env bash
set -euo pipefail

echo "Checking Terra/OpenAI bonus configuration..."

grep -q "DTLAB_PROVIDER='openai-codex'" dtlab_config.env
echo "PASS: provider = openai-codex"

grep -q "DTLAB_MODEL_ECONOMY='gpt-5.6-terra'" dtlab_config.env
grep -q "DTLAB_MODEL_FRONTIER='gpt-5.6-terra'" dtlab_config.env
echo "PASS: Terra model configured"

grep -q '1|2|3|7|8|9) HIST=on' provisioning/student_start.sh
grep -q '4|5|6) HIST=off' provisioning/student_start.sh
echo "PASS: 9-run history treatment mapping present"

grep -q '1|2|3|4|5|6) echo persona' provisioning/student_start.sh
grep -q '7|8|9) echo ablated' provisioning/student_start.sh
echo "PASS: 9-run condition mapping present"

grep -q 'exec hermes --reasoning medium' provisioning/student_start.sh
echo "PASS: Hermes uses medium reasoning"

grep -q 'OpenAI Codex provider selected' provisioning/student_start.sh
echo "PASS: Anthropic API-key preflight bypass exists"

echo
echo "Terra 9-run bonus configuration: PASS"
